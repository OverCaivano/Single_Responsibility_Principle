
from Controller.reporte_controller import ReporteController

if __name__ == "__main__":
    controller = ReporteController()
    controller.ejecutar_reporte()
