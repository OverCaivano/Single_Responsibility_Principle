class FuenteDatos:
    def obtener(self):
        return [10, 20, 30, 40, 50]
