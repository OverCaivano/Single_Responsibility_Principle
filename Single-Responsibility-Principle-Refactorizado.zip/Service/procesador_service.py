class ProcesadorDatos:
    def calcular_promedio(self, datos):
        return sum(datos) / len(datos)
